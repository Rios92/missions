class TFT {
    class functions {
        file = "functions";
        class addActions;
    };
};
